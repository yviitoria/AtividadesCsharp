using System;

class Q10 {
    // Método estático que determina a categoria do nadador com base na idade.
    public static char Categoria(int idade) {
        // Verifica se a idade é menor que 5 anos, o que não é permitido para nadadores.
        if (idade < 5) {
            Console.WriteLine("Idade inválida. O nadador(a) deve ter no mínimo 5 anos!");
            return ' '; // Retorna um espaço em branco para indicar um resultado inválido.
        }

        // Estrutura de decisão para determinar a categoria com base na idade.
        if (idade < 8) {
            return 'F';
        } else if (idade < 11) {
            return 'E';
        } else if (idade < 14) {
            return 'D';
        } else if (idade < 16) {
            return 'C';
        } else if (idade < 18) {
            return 'B';
        } else {
            return 'A';
        }
    }

    // Método de teste para interagir com o usuário.
    public static void Teste() {
        Console.WriteLine("\n\nQuestão 10\n");
        Console.WriteLine("Informe a idade do nadador(a):");
        int idade = Convert.ToInt32(Console.ReadLine()); // Lê a idade fornecida pelo usuário.

        char categoria = Categoria(idade); // Chama o método para determinar a categoria com base na idade.

        // Verifica se a categoria é válida (não é um espaço em branco) e imprime a categoria.
        if (categoria != ' ') {
            Console.WriteLine("Sua categoria é " + categoria + ".");
        }
    }
}