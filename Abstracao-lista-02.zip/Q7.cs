using System;

class Q7 {
    // Método estático para identificar o conceito com base na média final.
    public static void IdentificarConceito(double mediaFinal) {
        char conceito; // Variável para armazenar o conceito.

        // Verifica se a média final é um valor válido (maior ou igual a 0).
        if (mediaFinal >= 0) {
            // Estrutura de decisão para determinar o conceito com base na média final.
            if (mediaFinal <= 39) {
                conceito = 'F';
            } else if (mediaFinal <= 59) {
                conceito = 'E';
            } else if (mediaFinal <= 69) {
                conceito = 'D';
            } else if (mediaFinal <= 79) {
                conceito = 'C';
            } else if (mediaFinal < 89) {
                conceito = 'B';
            } else {
                conceito = 'A';
            }

            // Imprime o conceito determinado.
            Console.WriteLine($"Conceito: {conceito}");
        } else {
            // Se a média final for inválida (menor que 0), imprime uma mensagem de erro.
            Console.WriteLine("Média inválida. Deve ser maior que 0.");
        }
    }

    // Método para teste interativo com o usuário.
    public static void Teste() {
        Console.WriteLine("\n\nQuestão 07\n");
        Console.WriteLine("Digite a média final:");
        double mediaFinal = Convert.ToDouble(Console.ReadLine()); // Lê a média final fornecida pelo usuário.

        // Chama o método para identificar o conceito com a média fornecida pelo usuário.
        IdentificarConceito(mediaFinal);
    }
}