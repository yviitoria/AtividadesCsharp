using System;

class Q1
{
    // Método que calcula a média aritmética ou ponderada com base nos parâmetros fornecidos.
    public static void CalculaMedia(double n1, double n2, double n3, string letra, ref double mediaA, ref double mediaP)
    {
        // Verifica se a letra é "A" ou "a" para calcular a média aritmética.
        if (letra == "A" || letra == "a")
        {
            mediaA = (n1 + n2 + n3) / 3;  // Calcula a média aritmética.
            Console.WriteLine($"A média das notas é: {mediaA}.");  // Exibe a média aritmética.
        }
        // Verifica se a letra é "P" ou "p" para calcular a média ponderada.
        else if (letra == "P" || letra == "p")
        {
            mediaP = (n1 * 5 + n2 * 3 + n3 * 2) / 10;  // Calcula a média ponderada.
            Console.WriteLine($"A média das notas é: {mediaP}.");  // Exibe a média ponderada.
        }
        else
        {
            // Mensagem de erro caso a letra fornecida não seja "A", "a", "P" ou "p".
            Console.WriteLine("A letra digitada deve ser A (para calcular a média aritmética) ou P (para calcular a média ponderada).");
        }
    }

    // Método de teste para interagir com o usuário e obter as notas e a escolha de média.
    public static void Teste()
    {
        Console.WriteLine("\n\nQuestão 01\n");
        // Solicita ao usuário a quantidade de alunos.
        Console.WriteLine("Informe a quantidade de alunos:");
        int alunos = Convert.ToInt32(Console.ReadLine());

        // Laço para processar cada aluno.
        for (int i = 0; i < alunos; i++)
        {
            double n1;
            double n2;
            double n3;
            string letra;
            double mediaA = 0;
            double mediaP = 0;

            // Solicita a primeira nota do aluno.
            Console.WriteLine("Digite a primeira nota:");
            n1 = Convert.ToDouble(Console.ReadLine());

            // Solicita a segunda nota do aluno.
            Console.WriteLine("Digite a segunda nota:");
            n2 = Convert.ToDouble(Console.ReadLine());

            // Solicita a terceira nota do aluno.
            Console.WriteLine("Digite a terceira nota:");
            n3 = Convert.ToDouble(Console.ReadLine());

            // Solicita ao usuário que escolha o tipo de média a ser calculada.
            Console.WriteLine("- Digite A para calcular a média aritmética das notas.\n- Digite P para calcular a média ponderada das notas.");
            letra = Console.ReadLine();

            // Chama o método CalculaMedia para calcular a média com base nas notas e na escolha do usuário.
            CalculaMedia(n1, n2, n3, letra, ref mediaA, ref mediaP);
        }
    }
}