
 using System;
 class Q9{
 public static double CalculaMediaAprovados(int numAlunos){
 double notaAprovados = 0;
 double numAprovados = 0;
 //Aplicando comando de repetição para testar a nota de cada aluno
 for(int i = 0; i < numAlunos; i++){
 //Requisitando a nota do aluno
 Console.Write($"Insira a nota do {i+1}º aluno: ");
 double nota = Convert.ToInt32(Console.ReadLine());
 //Verificando se o aluno foi aprovado
 if(nota >= 6){
 //Somando a nota de cada aluno aprovado
 notaAprovados += nota;
 //Adicionando cada aluno aprovado
 numAprovados++;
 }
 }
 //Verificando se há algum aluno aprovado
 if (numAprovados > 0)
 {
 //Calculando a média das notas dos alunos aprovados e retornando o resultado
 double mediaAprovados = notaAprovados / numAprovados;
 return mediaAprovados;
 }else{
 //Retornando 0 caso não haja nenhum aluno aprovado
 return 0;
 }
 }
 public static void Teste(){
 Console.WriteLine("\n\nQuestão 09\n");

 //Requisitando o número de alunos ao usuário
 Console.Write("Insira o número de alunos: ");
 int numAlunos = Convert.ToInt32(Console.ReadLine());

 //Armazenando o resultado da função na variável para chamar a função apenas uma vez
 double mediaAprovados = CalculaMediaAprovados(numAlunos);
 //Testando se nenhum aluno foi aprovado
 if(mediaAprovados == 0){
 Console.WriteLine("\nNenhum aluno foi aprovado.");
   }else{
 //Imprimindo o resultado da função com o numero de alunos inserido pelo usuário como parâmetro
 Console.WriteLine($"\nA média das notas dos alunos aprovados é: {mediaAprovados}");
 }
}
  }