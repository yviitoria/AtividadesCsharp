using System;

class Program
{
    public static void Main()
    {
        Q1.Teste();
        Q2.Teste();
        Q3.Teste();
        Q4.Teste();
        Q5.Teste();
        Q6.Teste();
        Q7.Teste();
        Q8.Teste();
        Q9.Teste();
        Q10.Teste();
        
    }
}
