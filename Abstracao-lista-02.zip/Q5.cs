
 using System;
 class Q5{
 //Aplicando função para calcular o máximo divisor comum
 public static int CalculaMDC(int numero1, int numero2){
 int mdc = 0;
 //Aplicando comando de repetição para testar todos os divisores até o menor número
 for(int i = 1; i <= numero1 || i <= numero2; i++){
 int divisor1 = numero1 % i;
 int divisor2 = numero2 % i;
 //Armazenando os divisores comuns e substituindo-os até o fim da repetição
 if(divisor1 == 0 && divisor2 == 0){
 mdc = i;
 }
 }
 return mdc;
 }
//Aplicando teste para requisitar os valores e executar a função com eles como parâmetros 
 public static void Teste(){
  
 Console.WriteLine("\n\nQuestão 05");
 int numero1, numero2;

 //Requisitando os valores ao usuário até ele inserir valores diferentes de zero
 do{
 Console.Write("\nInsira o primeiro número inteiro diferente de zero: ");
 numero1 = Convert.ToInt32(Console.ReadLine());
 Console.Write("Insira o segundo número inteiro diferente de zero: ");
 numero2 = Convert.ToInt32(Console.ReadLine());
 }while(numero1 == 0 || numero2 == 0);

 //Imprimindo o resultado e executando a função com os números inseridos pelo usuário como parâmetros
 Console.WriteLine($"O máximo divisor comum entre {numero1} e {numero2} é{CalculaMDC(numero1,numero2)}");
 }
 }
