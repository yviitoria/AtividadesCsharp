using System; 
class Q6 {

    // Método estático que verifica se um número é positivo.
    public static bool VerificaPositivo (int n) {
        return n > 0; // Retorna true se o número for maior que zero, caso contrário, retorna false.
    }

    // Método estático que realiza a verificação de uma quantidade definida de números.
    public static void Teste () {
        Console.WriteLine("\n\nQuestão 06\n");
        // Solicita ao usuário que informe a quantidade de números a verificar.
        Console.WriteLine("Quantos números deseja verificar?");
        int quantidade = Convert.ToInt32 (Console.ReadLine()); // Lê a entrada do usuário e converte para inteiro.

        // Laço de repetição que executa 'quantidade' vezes.
        for(int i = 0; i < quantidade; i++) {
            // Solicita ao usuário que informe um número.
            Console.WriteLine($"Digite o {i+1}° número:");
            int n = Convert.ToInt32(Console.ReadLine()); // Lê a entrada do usuário e converte para inteiro.

            // Chama o método VerificaPositivo para verificar se o número é positivo.
            bool ehPositivo = VerificaPositivo(n);

            // Verifica o resultado da chamada ao método VerificaPositivo e imprime a mensagem apropriada.
            if (ehPositivo) {
                Console.WriteLine($"{n} é positivo!"); // Se o número for positivo, imprime mensagem correspondente.
            } else if (n == 0){
                Console.WriteLine("0 é um número neutro!"); // Se o número for zero, imprime mensagem correspondente.
            } else {
                Console.WriteLine($"{n} é negativo!"); // Se o número for negativo, imprime mensagem correspondente.
            }
        }
    }
}