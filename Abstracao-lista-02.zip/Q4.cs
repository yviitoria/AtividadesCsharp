using System;
using System.Net.NetworkInformation;

class Q4
{
    // Método que determina o tipo de triângulo com base nos comprimentos dos lados fornecidos.
    public static void Triangulo(double x, double y, double z)
    {
        // Verifica se os valores fornecidos podem formar um triângulo.
        if (x >= (y + z) || y >= (x + z) || z >= (x + y))
        {
            Console.WriteLine("Não é possível formar um triângulo com esses valores!");  // Mensagem de erro se os lados não formam um triângulo.
            return;
        }

        // Verifica se o triângulo é equilátero (todos os lados iguais).
        if (x == y && y == z)
        {
            Console.WriteLine("O triângulo é equilátero");
        }
        // Verifica se o triângulo é escaleno (todos os lados diferentes).
        else if (x != y && y != z && z != x)
        {
            Console.WriteLine("O triângulo é escaleno!");
        }
        // Se não é equilátero nem escaleno, deve ser isósceles (dois lados iguais).
        else
        {
            Console.WriteLine("O triângulo é isósceles!");
        }
    }

    // Método de teste para interagir com o usuário e obter os lados do triângulo.
    public static void Teste()
    {
        Console.WriteLine("\n\nQuestão 04\n");
        // Solicita ao usuário o comprimento do primeiro lado do triângulo.
        Console.WriteLine("Digite o primeiro lado do triângulo: ");
        double x = Convert.ToDouble(Console.ReadLine());

        // Solicita ao usuário o comprimento do segundo lado do triângulo.
        Console.WriteLine("Digite o segundo lado do triângulo: ");
        double y = Convert.ToDouble(Console.ReadLine());

        // Solicita ao usuário o comprimento do terceiro lado do triângulo.
        Console.WriteLine("Digite o terceiro lado do triângulo: ");
        double z = Convert.ToDouble(Console.ReadLine());

        // Chama o método Triangulo para determinar o tipo de triângulo com base nos lados fornecidos.
        Triangulo(x, y, z);
    }
}