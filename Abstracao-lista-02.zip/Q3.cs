using System;
 class Q3{
 //Aplicando procedimento para ordenar os números
 public static void OrdenaCrescente(int numero1, int numero2, int numero3){
 //Declarando variável temporária para passar o valor de uma variável a outra
 int temp;

 //Verificando se o primeiro número é maior que o segundo e trocando os dois de lugar em caso afirmativo
 if(numero1 > numero2){
 temp = numero1;
 numero1 = numero2;
 numero2 = temp;
 }
 //Verificando se o primeiro número é maior que o terceiro e trocando os dois de lugar em caso afirmativo
 if(numero1 > numero3){
 temp = numero1;
 numero1 = numero3;
 numero3 = temp;
 }
 //Verificando se o segundo número é maior que o terceiro e trocando os dois de lugar em caso afirmativo.
 if(numero2 > numero3){
 temp = numero2;
 numero2 = numero3;
 numero3 = temp;
 }

 //Imprimindo os números ordenados
 Console.WriteLine($"\nA ordem dos números é: {numero1}, {numero2} e {numero3}"
);
 }

 //Aplicando teste para requisitar os números ao usuário
 public static void Teste(){
 Console.WriteLine("\n\nQuestão 03\n");
//Requisitando a quantidade de conjuntos a serem reordenados
Console.Write("Insira a quantidade de conjuntos: ");
 int n = Convert.ToInt32(Console.ReadLine());

//Aplicando comando de repetição para requisitar cada conjunto
 for(int i = 0; i < n; i++){

 Console.Write("\nInsira o primeiro número inteiro: ");
 int numero1 = Convert.ToInt32(Console.ReadLine());
 Console.Write("Insira o segundo número inteiro: ");
 int numero2 = Convert.ToInt32(Console.ReadLine());
 Console.Write("Insira o terceiro número inteiro: ");
 int numero3 = Convert.ToInt32(Console.ReadLine());
 //Transferindo os valores das variáveis para o procedimento
 OrdenaCrescente(numero1, numero2, numero3);
 }
 }
 }
