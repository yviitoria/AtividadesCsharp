using System;

class Q2
{
    // Método que calcula a média salarial com base na soma dos salários e no número de habitantes.
    public static void MediaSalario(double somaSalarios, int habitantes, out double media)
    {
        // Verifica se o número de habitantes é maior que 0 para evitar divisão por zero.
        if (habitantes > 0)
        {
            media = somaSalarios / habitantes;  // Calcula a média salarial.
        }
        else
        {
            media = 0;  // Se o número de habitantes for 0 ou negativo, a média é 0.
        }
    }

    // Método de teste para interagir com o usuário e obter os salários para calcular a média.
    public static void Teste()
    {
        Console.WriteLine("\n\nQuestão 02\n");
        // Solicita ao usuário a quantidade de habitantes.
        Console.WriteLine("Informe a quantidade de pessoas: ");
        int habitantes = Convert.ToInt32(Console.ReadLine());

        double media;
        double somaSalarios = 0;  // Inicializa a soma dos salários.
        double salario;

        // Solicita ao usuário que informe os salários de cada habitante.
        Console.WriteLine($"Informe os salários das {habitantes} pessoas para o cálculo da média: ");
        for (int i = 0; i < habitantes; i++)
        {
            salario = Convert.ToDouble(Console.ReadLine());  // Lê o salário do habitante atual.
            somaSalarios += salario;  // Adiciona o salário à soma total.
        }

        // Chama o método MediaSalario para calcular a média salarial.
        MediaSalario(somaSalarios, habitantes, out media);

        // Exibe a média salarial calculada.
        Console.WriteLine($"A média salarial da população é de: {media}");
    }
}