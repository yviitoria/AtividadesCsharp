using System;
 class Q8{
 //Aplicando função para calcular a fórmula de s
 public static double CalculaValorDeS(int n){
 double s = 0;
 //Aplicando comando de repetição para calcular a fórmula para cada número antes do 'n', somar essa fórmula em cada iteração e atribuir a s 
 for(int i = 1; i <= n; i++){
 s += (i*i+1.0)/(i+3.0);
 }
 return s;
 }
 public static void Teste(){
 Console.WriteLine("\n\nQuestão 08\n");
 //Requisitando o numero ao usuário
 Console.Write("Insira um número inteiro: ");
 int n = Convert.ToInt32(Console.ReadLine());

 //Chamando a função com o número inserido pelo usuário como parâmetro e imprimindo o resultado
 Console.WriteLine($"O resultado da fórmula é: {CalculaValorDeS(n)}");
 }
 }